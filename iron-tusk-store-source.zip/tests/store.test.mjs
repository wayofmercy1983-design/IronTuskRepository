import {test} from 'node:test';
import assert from 'node:assert/strict';
import {products,normalizeCart,normalizeAddress,shipping,totals,assertExpectedTotal,sessionParams,fulfillmentXML,fulfill,kunakiXML,VERSION,checkoutOrigin} from '../functions/lib/store.mjs';
const cart=[{id:'PX00IMM4M3',quantity:1},{id:'PX00ZW89QC',quantity:1}];
const address=normalizeAddress({name:'Checkout Test',address_line_1:'123 Test Street',admin_area_2:'Hamilton',admin_area_1:'OH',postal_code:'45013',country_code:'US'});
const order={key:'a'.repeat(64),reference:'ITR-TEST',cart,address,shipping:{description:'USPS',price:12},amounts:totals(cart,{price:12}),sessionId:'cs_live_example',state:'awaiting_payment',expiresAt:2000000000};
const session={id:order.sessionId,metadata:{store_version:VERSION,order_key:order.key},client_reference_id:order.reference,currency:'usd',amount_total:7800,payment_status:'paid',status:'complete',livemode:true};
class Store{
 data=structuredClone(order);etag=0;
 async getWithMetadata(){return {data:structuredClone(this.data),etag:String(this.etag)};}
 async setJSON(key,data,options={}){if(options.onlyIfMatch!==undefined&&options.onlyIfMatch!==String(this.etag))return {modified:false};this.data=structuredClone(data);this.etag++;return {modified:true};}
}
process.env.CONTEXT='production';process.env.KUNAKI_MODE='LIVE';process.env.KUNAKI_AUTO_FULFILL='true';process.env.KUNAKI_USER_ID='test';process.env.KUNAKI_PASSWORD='test';process.env.STRIPE_SECRET_KEY='test';
test('full 18-product catalog and authoritative cents',()=>{assert.equal(products.size,18);assert.equal(products.get(cart[0].id).cents,1600);assert.equal(products.get(cart[1].id).cents,5000);assert.deepEqual(order.amounts,{subtotal:6600,shipping:1200,total:7800});});

test('ITR-012 charges $5 and sends the same CD ID to Kunaki',()=>{
 const cart=normalizeCart([{id:'PX00YPHI7O',quantity:1}]);
 const cdOrder={...order,cart,amounts:totals(cart,order.shipping)};
 const [line]=sessionParams(cdOrder,checkoutOrigin()).line_items;
 assert.equal(cdOrder.amounts.subtotal,500);
 assert.equal(line.price_data.unit_amount,500);
 assert.equal(line.price_data.product_data.metadata.kunaki_product_id,'PX00YPHI7O');
 assert.deepEqual(fulfillmentXML(cdOrder).Order.Product,[{ProductId:'PX00YPHI7O',Quantity:1}]);
});

test('new Tribal CD orders use the replacement ID at $16',()=>{
 const id='PX00ZKO739';
 const oldId='PX00AQ4XD2';
 const cart=normalizeCart([{id,quantity:1}]);
 assert.throws(()=>normalizeCart([{id:oldId,quantity:1}]));
 const cdOrder={...order,cart,amounts:totals(cart,order.shipping)};
 const [line]=sessionParams(cdOrder,checkoutOrigin()).line_items;
 assert.equal(line.price_data.unit_amount,1600);
 assert.equal(line.price_data.product_data.metadata.kunaki_product_id,id);
 assert.deepEqual(fulfillmentXML(cdOrder).Order.Product,[{ProductId:id,Quantity:1}]);
 assert.deepEqual(fulfillmentXML({...order,cart:[{id:oldId,quantity:1}]}).Order.Product,[{ProductId:oldId,Quantity:1}]);
});

test('shipping ITR-012 with Oklahoma sends Kunaki the same quote request as OK',async()=>{
 const cd=normalizeCart([{id:'PX00YPHI7O',quantity:1}]);
 const destination={...address,admin_area_2:'Norman',postal_code:'73069'};
 const transport=async(_url,{body})=>{
  assert.match(body,/<State_Province>OK<\/State_Province>/);
  assert.match(body,/<ProductId>PX00YPHI7O<\/ProductId>/);
  return new Response('<Response><ErrorCode>0</ErrorCode><Option><Description>USPS</Description><Price>6.29</Price></Option></Response>');
 };
 const fromName=await shipping(cd,normalizeAddress({...destination,admin_area_1:' Oklahoma '}),transport);
 assert.deepEqual(fromName,await shipping(cd,normalizeAddress({...destination,admin_area_1:'ok'}),transport));
});

test('province names and other countries remain supported and typos get a correction',()=>{
 assert.equal(normalizeAddress({...address,country_code:'CA',admin_area_1:'Québec'}).admin_area_1,'QC');
 assert.equal(normalizeAddress({...address,country_code:'GB',admin_area_1:'West Midlands'}).admin_area_1,'WEST MIDLANDS');
 assert.throws(()=>normalizeAddress({...address,admin_area_1:'Oklahmoa'}),error=>error.status===400&&/state name or its two-letter code/.test(error.publicMessage));
});

const decemberStart=Date.parse('2026-12-01T05:00:00Z');
const decemberEnd=Date.parse('2027-01-01T05:00:00Z');
const decemberShipping={description:'USPS',price:6.29};
const decemberCart=(...ids)=>normalizeCart(ids.map(id=>({id,quantity:1})));

test('CD special starts and ends at Eastern midnight and half price rounds to cents',()=>{
 const cds=decemberCart('PX00ZN9ZNN','PX00YPHI7O','PX00ZKO739');
 assert.equal(totals(cds,decemberShipping,decemberStart-1).subtotal,2475);
 const active=totals(cds,decemberShipping,decemberStart);
 assert.deepEqual(active,{subtotal:2288,shipping:629,total:2917,discounts:[{id:'PX00ZN9ZNN',cents:187,offer:'cd'}]});
 assert.deepEqual(totals(cds,decemberShipping,decemberEnd-1),active);
 assert.equal(totals(cds,decemberShipping,decemberEnd).subtotal,2475);
});

test('mixed formats do not qualify together and only full-size records unlock a 7-inch',()=>{
 for(const items of [
  decemberCart('PX00ZN9ZNN','PX00YPHI7O','PX00ZW89QC'),
  decemberCart('PX00ZW89QC','PX00HUOTT8','PX00ZWP1SF'),
  decemberCart('PX00ZW89QC','PX00H4Y785','PX00ZN9ZNN'),
 ])assert.equal(totals(items,decemberShipping,decemberStart).discounts,undefined);
});

test('a combined qualifying order discounts one unit per offer and keeps shipping and fulfillment quantities',()=>{
 const items=normalizeCart([
  {id:'PX00ZN9ZNN',quantity:6},{id:'PX00ZW89QC',quantity:2},
  {id:'PX00HUOTT8',quantity:1},{id:'PX00ZWP1SF',quantity:2},
 ]);
 const amounts=totals(items,decemberShipping,decemberStart);
 assert.equal(amounts.discounts.length,2);
 assert.equal(amounts.shipping,629);
 const placed={...order,cart:items,shipping:decemberShipping,amounts};
 const lines=sessionParams(placed,checkoutOrigin()).line_items;
 assert.deepEqual(lines.filter(line=>line.price_data.product_data.description?.includes('December')).map(line=>[line.quantity,line.price_data.unit_amount]).sort(),[[1,1250],[1,188]]);
 assert.equal(lines.reduce((sum,line)=>sum+line.quantity*line.price_data.unit_amount,0),amounts.subtotal);
 assert.deepEqual(fulfillmentXML(placed).Order.Product,items.map(item=>({ProductId:item.id,Quantity:item.quantity})));
 assert.doesNotThrow(()=>assertExpectedTotal(amounts.total,amounts));
 assert.throws(()=>assertExpectedTotal(amounts.total+1,amounts),{status:409});
});

test('corrected CD is accepted and retired CD cannot start a new checkout',()=>{
 assert.deepEqual(normalizeCart([{id:'PX00IMM4M3',quantity:1}]),[{id:'PX00IMM4M3',quantity:1}]);
 assert.equal(products.get('PX00H4Y785').cents,5000);
 assert.throws(()=>normalizeCart([{id:'PX00FFSL4M',quantity:1}]));
 assert.equal(products.has('PX008Q8MCO'),false);
 assert.throws(()=>normalizeCart([{id:'PX008Q8MCO',quantity:1}]));
});

test('an already submitted original CD order is never resubmitted',async()=>{
 const store=new Store();store.data.cart=[{id:'PX008Q8MCO',quantity:1}];store.data.state='fulfilled';
 let calls=0;const result=await fulfill(session,store,async()=>{calls++;throw Error('must not submit');});
 assert.equal(result.fulfillment,'submitted');assert.equal(calls,0);
 assert.equal(store.data.cart[0].id,'PX008Q8MCO');
});
test('rejects unknown products, duplicate rows and invalid quantities',()=>{for(const c of [[{id:'fake',quantity:1}],[cart[0],cart[0]],[{...cart[0],quantity:-1}],[{...cart[0],quantity:1.5}],[{...cart[0],quantity:26}]])assert.throws(()=>normalizeCart(c));});
test('Stripe lines and fulfillment retain exact format IDs and prices',()=>{const p=sessionParams(order,'https://irontuskrecords.com');assert.deepEqual(p.line_items.map(x=>x.price_data.unit_amount),[1600,5000]);assert.deepEqual(p.line_items.map(x=>x.price_data.product_data.metadata.kunaki_product_id),cart.map(x=>x.id));assert.deepEqual(fulfillmentXML(order).Order.Product,cart.map(x=>({ProductId:x.id,Quantity:x.quantity})));});
test('parses the HTML-wrapped XML actually returned by Kunaki',async()=>{assert.equal((await kunakiXML({},async()=>new Response('<HTML><BODY><Response><ErrorCode>0</ErrorCode><OrderId>123</OrderId></Response>'))).OrderId,'123');});
test('unpaid, mismatched and test sessions never manufacture',async()=>{let calls=0;const f=async()=>{calls++;throw Error('unexpected')};assert.equal((await fulfill({...session,payment_status:'unpaid'},new Store(),f)).paid,false);assert.equal((await fulfill({...session,livemode:false},new Store(),f)).fulfillment,'test_payment');await assert.rejects(fulfill({...session,amount_total:1},new Store(),f));assert.equal(calls,0);});
test('concurrent and repeated delivery submits only once',async()=>{const store=new Store();let calls=0;const f=async()=>{calls++;return new Response('<Response><ErrorCode>0</ErrorCode><OrderId>123</OrderId></Response>');};await Promise.allSettled([fulfill(session,store,f,'https://irontuskrecords.com/.netlify/functions/stripe-webhook'),fulfill(session,store,f,'https://irontuskrecords.com/.netlify/functions/stripe-webhook')]);await fulfill(session,store,f,'https://irontuskrecords.com/.netlify/functions/stripe-webhook');assert.equal(calls,1);assert.equal(store.data.state,'fulfilled');});
test('ambiguous Kunaki timeout is saved for review and never resubmitted',async()=>{const store=new Store();let calls=0;const f=async()=>{calls++;throw Error('timeout')};await assert.rejects(fulfill(session,store,f,'https://irontuskrecords.com/.netlify/functions/stripe-webhook'));await assert.rejects(fulfill(session,store,f,'https://irontuskrecords.com/.netlify/functions/stripe-webhook'));assert.equal(calls,1);assert.equal(store.data.state,'manual_review');});

test('checkout always returns to the live store, without build-only runtime variables',()=>{delete process.env.CONTEXT;delete process.env.DEPLOY_PRIME_URL;assert.equal(checkoutOrigin(),'https://irontuskrecords.com');});

test('card checkout opens a card-only Stripe session with the same prices, address and shipping',()=>{
 const normal=sessionParams(order,checkoutOrigin());
 const direct=sessionParams({...order,paymentMethod:'card'},checkoutOrigin());
 const {payment_method_types,wallet_options,...common}=direct;
 assert.deepEqual(payment_method_types,['card']);
 assert.deepEqual(wallet_options,{link:{display:'never'}});
 assert.deepEqual(common,normal);
 assert.deepEqual(sessionParams({...order,paymentMethod:'automatic'},checkoutOrigin()),normal);
});

test('unpublished URLs cannot trigger live manufacturing even with production credentials',async()=>{let calls=0;await assert.rejects(fulfill(session,new Store(),async()=>{calls++;},'https://example--iron-tusk-online.netlify.app/.netlify/functions/stripe-webhook'));assert.equal(calls,0);});
