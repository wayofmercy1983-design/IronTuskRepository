import test from 'node:test';
import assert from 'node:assert/strict';
import {currentQuarter,statementPeriod} from '../source/one-dist/quarter.js';
test('all months select the correct calendar quarter and year',()=>{
 for(const year of [2026,2027])for(let month=0;month<12;month++)assert.equal(currentQuarter(new Date(year,month,15,12)),`Q${[1,1,1,2,2,2,3,3,3,4,4,4][month]} ${year}`);
});
test('new entries follow quarter and year boundaries in the local calendar',()=>{
 assert.equal(statementPeriod(null,new Date(2026,2,31,23,59)),'Q1 2026');
 assert.equal(statementPeriod(null,new Date(2026,3,1,0,0)),'Q2 2026');
 assert.equal(statementPeriod(null,new Date(2026,11,31,23,59)),'Q4 2026');
 assert.equal(statementPeriod(null,new Date(2027,0,1,0,0)),'Q1 2027');
});
test('editing preserves historical, custom and missing periods without changing the record',()=>{
 for(const period of ['Q2 2025','September 2026','',null,undefined]){
  const record={period,notes:'Keep terms and notes'};assert.equal(statementPeriod(record,new Date(2026,9,31)),period??'');assert.deepEqual(record,{period,notes:'Keep terms and notes'});
 }
});
