import test from 'node:test';
import assert from 'node:assert/strict';
import {grossFor} from '../source/one-dist/stripe-gross.js';
import {calculateSale} from '../functions/lib/one/stripe-royalties.mjs';
const row={id:'sale:line',artistId:'a',releaseId:'r',soldOn:'2026-10-01',salesCents:375,grossIssues:[]};
const report=rows=>({complete:true,checkedAt:'2026-11-02T00:00:00Z',rows});
test('gross filters by artist, release and quarter and sums integer cents',()=>{
 const result=grossFor(report([row,{...row,id:'second',salesCents:1600},{...row,id:'other',releaseId:'other'},{...row,id:'past',soldOn:'2026-09-30'},{...row,id:'year',soldOn:'2025-10-01'}]),'a','r','Q4 2026');
 assert.equal(result.cents,1975);assert.equal(result.count,2);assert.equal(grossFor(report([row]),'other','r','Q4 2026').cents,0);
});
test('incomplete scans, ambiguous periods, duplicate rows and unresolved matches are blocked',()=>{
 assert.throws(()=>grossFor({...report([row]),complete:false},'a','r','Q4 2026'),/incomplete/);
 assert.throws(()=>grossFor(report([row]),'a','r','2026'),/quarter/);
 assert.throws(()=>grossFor(report([row,row]),'a','r','Q4 2026'),/duplicate/);
 assert.throws(()=>grossFor(report([{...row,releaseId:null}]),'a','r','Q4 2026'),/release match/);
});
test('unverified and refunded selected sales cannot silently become gross revenue',()=>{
 for(const change of [{grossIssues:['refund']},{salesCents:null},{grossIssues:undefined}])assert.throws(()=>grossFor(report([{...row,...change}]),'a','r','Q4 2026'),/unverified/);
});
test('gross does not depend on manufacturing cost, contract, or processing fees',()=>{
 const base={session:{id:'s',livemode:true,status:'complete',payment_status:'paid',currency:'usd',created:1793188800,amount_total:1025,total_details:{amount_shipping:600}},lines:[{id:'line',quantity:1,currency:'usd',amount_total:425,amount_tax:25,price:{product:{id:'p',metadata:{kunaki_product_id:'K'}}}}],charge:{amount_refunded:0,disputed:false,balance_transaction:null},releases:[{id:'r',artistId:'a',kunakiProductId:'K'}],contracts:[],catalog:[],costs:[]};
 const sale=calculateSale(base)[0];assert.equal(sale.releaseId,'r');assert.equal(sale.salesCents,400);assert.deepEqual(sale.grossIssues,[]);assert.equal(sale.artistCents,null);assert.equal(grossFor(report([sale]),'a','r','Q4 2026').cents,400);
 for(const change of [{charge:null},{charge:{...base.charge,amount_refunded:10}},{charge:{...base.charge,disputed:true}},{session:{...base.session,amount_total:9999}},{session:{...base.session,currency:'eur'}}])assert.ok(calculateSale({...base,...change})[0].grossIssues.length);
});
