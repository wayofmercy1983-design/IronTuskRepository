import test from 'node:test';
import assert from 'node:assert/strict';
import {verifiedVisitor,ensureCustomer,accountKey,attachCustomer,ORIGIN,problem} from '../functions/lib/customers.mjs';
import {createHandler} from '../functions/customer-account.mjs';
import {sessionParams,VERSION} from '../functions/lib/store.mjs';
const user={id:'user-a',email:'test@example.invalid',name:'Test'};
const req=(action='me',options={})=>new Request(ORIGIN+'/.netlify/functions/customer-account?action='+action,options);
function store(initial={}){const data=new Map(Object.entries(initial));return {get:async key=>data.get(key)||null,setJSON:async(key,value,opts={})=>{if(opts.onlyIfNew&&data.has(key))return {modified:false};data.set(key,value);return {modified:true};}};}
test('anonymous, forged, expired and unconfirmed visitors cannot access customer data',async()=>{
 assert.equal(await verifiedVisitor(req(),{optional:true}),null);
 await assert.rejects(verifiedVisitor(req()),e=>e.status===401);
 for(const response of [new Response('{}',{status:401}),Response.json({id:'a',email:'a@example.invalid'})])await assert.rejects(verifiedVisitor(req('me',{headers:{cookie:'nf_jwt=forged.token.value'}}),{transport:async()=>response}));
 const result=await verifiedVisitor(req('me',{headers:{cookie:'nf_jwt=valid.token.value'}}),{transport:async(url,options)=>{assert.equal(url,ORIGIN+'/.netlify/identity/user');assert.equal(options.headers.Authorization,'Bearer valid.token.value');return Response.json({id:user.id,email:user.email,confirmed_at:'2026-01-01',user_metadata:{full_name:'Test'}});}});assert.deepEqual(result,user);
});
test('Stripe customer is created once per verified user and never selected by email',async()=>{
 const db=store();let count=0;const stripe={customers:{create:async(data,opts)=>{count++;assert.equal(data.metadata.iron_tusk_account_id,user.id);assert.ok(opts.idempotencyKey);return {id:'cus_owned'};}}};
 assert.equal((await ensureCustomer(user,db,stripe)).customerId,'cus_owned');await ensureCustomer({...user,email:'changed@example.invalid'},db,stripe);assert.equal(count,1);
});
test('signed-in checkout preserves totals, shipping, metadata and fulfillment identifiers; guests unchanged',()=>{
 const order={key:'a'.repeat(64),reference:'ITR-TEST',cart:[{id:'PX00IMM4M3',quantity:2}],amounts:{shipping:629},shipping:{description:'Mail'},expiresAt:2000000000};
 const base=sessionParams(order,ORIGIN),account={userId:user.id,customerId:'cus_owned'},params=attachCustomer(base,account);
 assert.equal(attachCustomer(base,null),base);assert.deepEqual(params.line_items,base.line_items);assert.deepEqual(params.shipping_options,base.shipping_options);assert.equal(params.customer,'cus_owned');assert.equal(params.metadata.order_key,order.key);assert.equal(params.payment_intent_data.metadata.order_key,order.key);assert.equal(params.saved_payment_method_options.payment_method_save,'enabled');assert.equal(params.payment_intent_data.setup_future_usage,undefined);
});
test('account routes require authentication and reject cross-origin portal requests',async()=>{
 const handler=createHandler({authenticate:async()=>{throw problem('Sign in',401);}});
 assert.equal((await handler(req())).status,401);
 assert.equal((await handler(req('portal',{method:'POST',headers:{origin:'https://other.test'}}))).status,403);
 assert.equal((await handler(req('portal'))).status,405);
});
test('portal ignores caller customer IDs and uses only the authenticated owner mapping',async()=>{
 const db=store({[accountKey(user.id)]:{userId:user.id,customerId:'cus_owned'},'portal-configuration':{id:'bpc_own'}});let called;
 const handler=createHandler({authenticate:async()=>user,accounts:()=>db,payments:()=>({billingPortal:{sessions:{create:async params=>{called=params;return {url:'https://billing.stripe.com/p/session/test'};}}}})});
 const response=await handler(req('portal',{method:'POST',headers:{origin:ORIGIN},body:JSON.stringify({customerId:'cus_victim'})}));assert.equal(response.status,200);assert.equal(called.customer,'cus_owned');assert.equal(called.return_url,ORIGIN+'/account/');
});
test('order history is customer-scoped and excludes another account or guest order',async()=>{
 const key='a'.repeat(64),account={userId:user.id,customerId:'cus_owned'},db=store({[accountKey(user.id)]:account});
 const order={key,customerAccountId:user.id,reference:'ITR-TEST',sessionId:'cs_live_owned',amounts:{total:1600},cart:[{id:'PX00FFSL4M',quantity:1}],createdAt:'2026-11-01',state:'fulfilled'};
 const paid={id:order.sessionId,customer:'cus_owned',livemode:true,payment_status:'paid',status:'complete',amount_total:1600,currency:'usd',client_reference_id:order.reference,metadata:{order_key:key,store_version:VERSION}};
 let current=order;const handler=createHandler({authenticate:async()=>user,accounts:()=>db,orderStore:()=>({get:async()=>current}),payments:()=>({checkout:{sessions:{list:async params=>{assert.equal(params.customer,'cus_owned');return {data:[paid,{...paid,id:'cs_live_victim',customer:'cus_victim'}],has_more:false};},retrieve:async()=>({customer:'cus_victim'})}}})});
 const data=await (await handler(req('orders'))).json();assert.equal(data.orders.length,1);assert.equal(data.orders[0].reference,order.reference);assert.equal(data.orders[0].address,undefined);
 current={...order,customerAccountId:'other'};assert.equal((await (await handler(req('orders'))).json()).orders.length,0);
 current={...order,customerAccountId:undefined};assert.equal((await (await handler(req('orders'))).json()).orders.length,0);
 assert.equal((await handler(req('orders&after=cs_live_victim'))).status,403);
});
