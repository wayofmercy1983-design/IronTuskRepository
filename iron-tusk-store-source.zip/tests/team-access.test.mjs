import test from 'node:test';
import assert from 'node:assert/strict';
import {teamAccess} from '../functions/lib/one/team-access.mjs';
import {createHandler} from '../functions/one-api.mjs';
import {digest} from '../functions/lib/one/security.mjs';
const origin='https://irontuskrecords.com';
const request=(action='records',options={})=>new Request(origin+'/.netlify/functions/one-api?action='+action,{headers:{cookie:'nf_jwt=example.token.value'},...options});
const identity={id:'paul-test',email:'Paul@example.invalid',confirmed_at:'2026-11-01'};
test('team access requires an exact, verified, server-approved email',async()=>{
 const options={allowedEmails:'paul@example.invalid',transport:async()=>Response.json(identity)};
 assert.equal(await teamAccess(request(),options),true);
 assert.equal(await teamAccess(request(),{...options,allowedEmails:''}),false);
 for(const user of [{...identity,email:'other@example.invalid',app_metadata:{roles:['admin']}},{...identity,email:'paul+other@example.invalid'},{...identity,confirmed_at:undefined}])assert.equal(await teamAccess(request(),{...options,transport:async()=>Response.json(user)}),false);
 assert.equal(await teamAccess(request(),{...options,transport:async()=>new Response('{}',{status:401})}),false);
 assert.equal(await teamAccess(request(),{...options,transport:async()=>{throw Error('offline');}}),false);
 assert.equal(await teamAccess(new Request(origin),options),false);
});
test('approved team can read and save all workspace records; other customers cannot',async()=>{
 const previous=process.env.ITR_ONE_TEAM_EMAILS;process.env.ITR_ONE_TEAM_EMAILS='paul@example.invalid';
 try{
  const records=new Map([['owner',{hash:'existing'}]]);const db={get:async k=>records.get(k)||null,getWithMetadata:async k=>records.has(k)?{data:records.get(k),etag:'v1'}:null,setJSON:async(k,data)=>{records.set(k,data);return {modified:true};},delete:async k=>records.delete(k)};
  let signedIn=identity;const handler=createHandler({storage:()=>db,transport:async()=>Response.json(signedIn)});
  assert.equal((await handler(request())).status,200);
  const post=request('records',{method:'POST',headers:{origin,cookie:'nf_jwt=example.token.value'},body:JSON.stringify({key:'artists',data:[{id:'artist-test',name:'Test'}],etag:null})});
  assert.equal((await handler(post)).status,200);assert.equal(records.get('records/artists')[0].id,'artist-test');
  signedIn={...identity,email:'shopper@example.invalid'};assert.equal((await handler(request())).status,401);
  const ownerToken='owner-test-token';records.set('sessions/'+digest(ownerToken),{expires:Date.now()+60000});assert.equal((await handler(request('records',{headers:{cookie:'itr_one='+ownerToken}}))).status,200);
  const response=await handler(request('logout',{method:'POST',headers:{origin,cookie:'itr_one='+ownerToken}}));const cookies=response.headers.getSetCookie();assert.equal(cookies.length,3);assert.ok(cookies.some(c=>c.startsWith('nf_jwt=;')));assert.ok(cookies.some(c=>c.startsWith('nf_refresh=;')));assert.equal(records.has('sessions/'+digest(ownerToken)),false);
 }finally{if(previous===undefined)delete process.env.ITR_ONE_TEAM_EMAILS;else process.env.ITR_ONE_TEAM_EMAILS=previous;}
});
