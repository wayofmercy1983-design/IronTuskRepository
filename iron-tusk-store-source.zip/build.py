from pathlib import Path
import hashlib, json, re, shutil
root=Path(__file__).resolve().parent
s=(root/'source/oct22-store.js').read_text()
# Keep the October 22 React application, cart and catalog intact.
needle='function jr(){let{addToCart:e,totalItems:t}=rr()'
assert s.count(needle)==1
insertion='''(0,j.jsxs)(`section`,{className:`preorder-panel`,\"aria-labelledby\":`thomas-preorder-title`,children:[(0,j.jsx)(`img`,{src:`/shop/power-chords.png`,alt:`Power Chords and Other Nonsense album artwork`,width:180,height:180}),(0,j.jsxs)(`div`,{children:[(0,j.jsx)(`p`,{className:`shop-eyebrow`,children:`Thomas Ate the Cat · CD & vinyl`}),(0,j.jsx)(`h2`,{id:`thomas-preorder-title`,children:`Power Chords and Other Nonsense`}),(0,j.jsx)(`p`,{className:`preorder-price`,children:`CD $16.00 · Vinyl $50.00 · plus shipping`}),(0,j.jsx)(`p`,{children:`Released October 30, 2026. CDs and vinyl ship as soon as Kunaki manufactures them.`}),(0,j.jsx)(`button`,{className:`shop-buy-button`,type:`button`,onClick:()=>{let t=Ar.find(t=>t.id===`PX00FFSL4M`);e({id:t.id,name:`${t.artist} — ${t.title} (${t.format})`,price:t.price}),r(t.id)},children:n===`PX00FFSL4M`?`Added to cart ✓`:`Buy CD`}),(0,j.jsx)(`button`,{className:`shop-buy-button preorder-vinyl`,type:`button`,onClick:()=>{let t=Ar.find(t=>t.id===`PX00ZW89QC`);e({id:t.id,name:`${t.artist} — ${t.title} (${t.format})`,price:t.price}),r(t.id)},children:n===`PX00ZW89QC`?`Added to cart ✓`:`Buy Vinyl`}),(0,j.jsx)(`p`,{className:`preorder-note`,children:`Add either format to your cart and pay securely through Stripe. Shipping is calculated for your whole order.`})]})]}),'''
preorders=json.loads((root/'source/preorders.json').read_text())
s=s.replace('var Ar=[','var Ar='+json.dumps(preorders,ensure_ascii=False,separators=(',',':'))[:-1]+',',1)
start=s.index(needle)
section='(0,j.jsx)(`section`,{className:`shop-products`,"aria-label":`Music available from Kunaki`'
pos=s.index(section,start)
s=s[:pos]+insertion+s[pos:]
# Route checkout to the preserved backend, retaining all server-side pricing,
# payment verification, durable orders, webhook signatures and fulfillment.
assert s.count('var Nr=`/.netlify/functions`')==1
s=s.replace('var Nr=`/.netlify/functions`','var Nr=`/store-api`')
assert len(re.findall(r'id:`PX[0-9A-Z]+`,artist:',s[s.index('var Ar='):s.index(needle)]))==14
assert 'stripe-create-session' in s and 'stripe-session-status' in s
name='store-'+hashlib.sha256(s.encode()).hexdigest()[:12]+'.js'
(root/'dist/assets'/name).write_text(s)
html=(root/'source/oct22-index.html').read_text().replace('index-CUCXquFJ.js',name).replace('<title>iron-tusk-online</title>','<title>Iron Tusk Records | Independent Music</title>')
html=html.replace('</head>','  <link rel="stylesheet" href="/preorders.css">\n  </head>')
(root/'dist/index.html').write_text(html)
(root/'dist/preorders.css').write_text('''.preorder-panel{display:grid;grid-template-columns:180px minmax(0,1fr);gap:28px;align-items:center;max-width:1100px;margin:0 auto 32px;padding:24px;border:1px solid #d4af37;background:#19141d;color:#fff}.preorder-panel img{display:block;width:180px;height:180px;object-fit:contain}.preorder-panel h2{margin:6px 0 12px;font-size:clamp(1.4rem,3vw,2rem);line-height:1.15}.preorder-panel p{line-height:1.55;margin:8px 0}.preorder-panel .preorder-price{font-size:1.15rem;font-weight:700;color:#e7c85a}.preorder-panel .shop-eyebrow{color:#e7c85a}.preorder-panel .preorder-note{font-size:.85rem;color:#d2cbd5}.preorder-panel button{min-height:44px;display:inline-flex;align-items:center;text-decoration:none}.preorder-panel .preorder-vinyl{margin-left:12px}.preorder-panel button:focus-visible{outline:3px solid #fff;outline-offset:4px}@media(max-width:600px){.preorder-panel{grid-template-columns:1fr;padding:18px;gap:16px}.preorder-panel img{margin:auto;width:160px;height:160px}}''')
backend='/.netlify/functions/'
routes=''.join(f'/store-api/{p} {backend}{p} 200!\n' for p in ['kunaki-shipping-options','stripe-create-session','stripe-session-status'])
# Preserve the existing Stripe webhook URL for outstanding payments as well.
# The deployed webhook function preserves this reserved Netlify route.
routes+='/one /one/ 301\n/one/* /one/index.html 200\n/* /index.html 200\n'
(root/'dist/_redirects').write_text(routes)
(root/'netlify.toml').write_text('[build]\n  command = "python3 build.py"\n  publish = "dist"\n')
print(json.dumps({'catalog_products':16,'cd_preorder_price':16,'bundle':name,'stripe_cart_preserved':True}))

with (root/"dist/preorders.css").open("a") as style_file:
 style_file.write('.artists-page .releases-header h1{color:#191817;font-size:clamp(2.2rem,6vw,4.5rem)}.artists-page .releases-header p{color:#4b4842}.artist-card.artist-link{color:#191817;text-decoration:none;font-weight:400}.artist-card .artist-location{color:#4b4842}.artist-card .artist-header{flex-direction:column;gap:7px}.artist-card .artist-bio{font-weight:400;line-height:1.5;min-height:6em}.artist-card .artist-banner{background:#191817}.artist-card .artist-banner img{object-fit:contain}.featured-artist-image{object-fit:contain;background:#191817}.artist-card .artist-button{text-decoration:underline}.artist-card .artist-overlay{text-decoration:none}.artist-card .artist-header h2{margin:0}.artists-page .artist-card:focus-within{outline:2px solid #8a2be2;outline-offset:2px}')

# Preserve the private manager when the public store is rebuilt.
shutil.copytree(root/"source/one-dist", root/"dist/one", dirs_exist_ok=True)
shutil.copy2(root/"source/one-headers", root/"dist/_headers")
