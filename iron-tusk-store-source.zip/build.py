from pathlib import Path
import hashlib, json, re, shutil
root=Path(__file__).resolve().parent
s=(root/'source/oct22-store.js').read_text()
# Keep the October 22 React application, cart and catalog intact.
needle='function jr(){let{addToCart:e,totalItems:t}=rr()'
assert s.count(needle)==1
insertion='''(0,j.jsxs)(`section`,{className:`preorder-panel`,\"aria-labelledby\":`thomas-preorder-title`,children:[(0,j.jsx)(`img`,{src:`/shop/power-chords.png`,alt:`Power Chords and Other Nonsense album artwork`,width:180,height:180}),(0,j.jsxs)(`div`,{children:[(0,j.jsx)(`p`,{className:`shop-eyebrow`,children:`Thomas Ate the Cat · CD & vinyl preorders`}),(0,j.jsx)(`h2`,{id:`thomas-preorder-title`,children:`Power Chords and Other Nonsense`}),(0,j.jsx)(`p`,{className:`preorder-price`,children:`$16.00 plus shipping`}),(0,j.jsx)(`p`,{children:`Release October 30, 2026. CD preorders ship as soon as Kunaki makes them; orders are not held until release day. See Kunaki for vinyl production and shipping details.`}),(0,j.jsx)(`a`,{className:`shop-buy-button`,href:`https://kunaki.com/Sales.asp?PID=PX008Q8MCO&PP=1`,target:`_blank`,rel:`noopener noreferrer`,children:`Pre-Order CD ↗`}),(0,j.jsx)(`a`,{className:`shop-buy-button preorder-vinyl`,href:`https://kunaki.com/VinylSales.asp?PID=PX00ZW89QC&OrderType=RetailSale&PP=1`,target:`_blank`,rel:`noopener noreferrer`,children:`Pre-Order Vinyl ↗`}),(0,j.jsx)(`p`,{className:`preorder-note`,children:`CD and vinyl preorders are purchased directly through Kunaki, with price and shipping confirmed there. Catalog purchases below use the Stripe cart.`})]})]}),'''
start=s.index(needle)
section='(0,j.jsx)(`section`,{className:`shop-products`,"aria-label":`Music available from Kunaki`'
pos=s.index(section,start)
s=s[:pos]+insertion+s[pos:]
# Route checkout to the preserved backend, retaining all server-side pricing,
# payment verification, durable orders, webhook signatures and fulfillment.
assert s.count('var Nr=`/.netlify/functions`')==1
s=s.replace('var Nr=`/.netlify/functions`','var Nr=`/store-api`')
assert len(re.findall(r'id:`PX[0-9A-Z]+`,artist:',s[s.index('var Ar='):s.index(needle)]))==14
assert 'stripe-create-session' in s and 'stripe-session-status' in s
name='store-'+hashlib.sha256(s.encode()).hexdigest()[:12]+'.js'
(root/'dist/assets'/name).write_text(s)
html=(root/'source/oct22-index.html').read_text().replace('index-CUCXquFJ.js',name).replace('<title>iron-tusk-online</title>','<title>Iron Tusk Records | Independent Music</title>')
html=html.replace('</head>','  <link rel="stylesheet" href="/preorders.css">\n  </head>')
(root/'dist/index.html').write_text(html)
(root/'dist/preorders.css').write_text('''.preorder-panel{display:grid;grid-template-columns:180px minmax(0,1fr);gap:28px;align-items:center;max-width:1100px;margin:0 auto 32px;padding:24px;border:1px solid #d4af37;background:#19141d;color:#fff}.preorder-panel img{display:block;width:180px;height:180px;object-fit:contain}.preorder-panel h2{margin:6px 0 12px;font-size:clamp(1.4rem,3vw,2rem);line-height:1.15}.preorder-panel p{line-height:1.55;margin:8px 0}.preorder-panel .preorder-price{font-size:1.15rem;font-weight:700;color:#e7c85a}.preorder-panel .shop-eyebrow{color:#e7c85a}.preorder-panel .preorder-note{font-size:.85rem;color:#d2cbd5}.preorder-panel a{min-height:44px;display:inline-flex;align-items:center;text-decoration:none}.preorder-panel .preorder-vinyl{margin-left:12px}.preorder-panel a:focus-visible{outline:3px solid #fff;outline-offset:4px}@media(max-width:600px){.preorder-panel{grid-template-columns:1fr;padding:18px;gap:16px}.preorder-panel img{margin:auto;width:160px;height:160px}}''')
backend='https://6adaa9237f3da7b6ab3976a2--iron-tusk-online.netlify.app/.netlify/functions/'
routes=''.join(f'/store-api/{p} {backend}{p} 200!\n' for p in ['kunaki-shipping-options','stripe-create-session','stripe-session-status'])
# Preserve the existing Stripe webhook URL for outstanding payments as well.
routes+=f'/.netlify/functions/stripe-webhook {backend}stripe-webhook 200!\n'
routes+='/* /index.html 200\n'
(root/'dist/_redirects').write_text(routes)
(root/'netlify.toml').write_text('[build]\n  command = "python3 build.py"\n  publish = "dist"\n')
print(json.dumps({'catalog_products':14,'cd_preorder_price':16,'bundle':name,'stripe_cart_preserved':True}))
