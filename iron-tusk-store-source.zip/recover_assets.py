from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from urllib.request import urlopen
from urllib.parse import quote
import hashlib, json
root=Path(__file__).resolve().parent
base="https://6adaa9237f3da7b6ab3976a2--iron-tusk-online.netlify.app"
hashes=json.loads((root/"source/assets-sha256.json").read_text())
def get(item):
 path,digest=item
 dest=root/"dist"/path.lstrip("/")
 if dest.exists() and hashlib.sha256(dest.read_bytes()).hexdigest()==digest:return
 with urlopen(base+quote(path,safe="/"),timeout=60) as response:data=response.read()
 assert hashlib.sha256(data).hexdigest()==digest, "Asset checksum mismatch: "+path
 dest.parent.mkdir(parents=True,exist_ok=True)
 dest.write_bytes(data)
with ThreadPoolExecutor(max_workers=6) as pool:list(pool.map(get,hashes.items()))
print("Verified",len(hashes),"preserved store assets")
