import {syncProducts,saveChoice} from './lib/one/product-sync.mjs';
import {contractFiles} from './lib/one/contract-files.mjs';
import {getStore} from '@netlify/blobs';
import Stripe from 'stripe';
import {XMLBuilder,XMLParser} from 'fast-xml-parser';
import catalog from '../source/catalog.json' with {type:'json'};
import {digest,passwordHash,checkPassword,sessionToken,allowedKeys,validateCollection,publicOrder} from './lib/one/security.mjs';
const ORIGIN='https://irontuskrecords.com';
export function createHandler({storage=getStore,Payments=Stripe,transport=fetch}={}) {
const store=()=>storage({name:'iron-tusk-one-private-v1',consistency:'strong'});
const orders=()=>storage({name:'itr-stripe-v2',consistency:'strong'});
const json=(value,status=200,headers={})=>new Response(JSON.stringify(value),{status,headers:{'content-type':'application/json','cache-control':'no-store','x-content-type-options':'nosniff',...headers}});
const cookie=(token,age=28800)=>`itr_one=${token}; Path=/.netlify/functions/one-api; HttpOnly; Secure; SameSite=Strict; Max-Age=${age}`;
async function body(request){const t=await request.text();if(t.length>3000000)throw Error('Request too large');return JSON.parse(t);}
async function authenticated(request,db){const token=request.headers.get('cookie')?.match(/(?:^|;\s*)itr_one=([^;]+)/)?.[1];if(!token||token.length>100)return false;const s=await db.get('sessions/'+digest(token),{type:'json'});return s&&s.expires>Date.now();}
async function issue(db){const token=sessionToken();await db.setJSON('sessions/'+digest(token),{expires:Date.now()+28800000});return json({ok:true},200,{'set-cookie':cookie(token)});}
return async request=>{
 try{
  const url=new URL(request.url),action=url.searchParams.get('action')||'me',db=store();
  if(request.method!=='GET'&&request.method!=='POST')return json({error:'Method not allowed'},405);
  if(request.method==='POST'&&request.headers.get('origin')!==ORIGIN)return json({error:'Origin rejected'},403);
  if(action==='me'&&request.method==='GET')return json({authenticated:Boolean(await authenticated(request,db)),setupRequired:!(await db.get('owner',{type:'json'}))});
  if(action==='setup'&&request.method==='POST'){
   const {token,password}=await body(request);const setup=await db.get('setup',{type:'json'});
   if(typeof token!=='string'||typeof password!=='string'||password.length<14||password.length>256||!setup||setup.expires<Date.now()||digest(token)!==setup.hash)return json({error:'Setup link expired or password is too short (14 characters minimum).'},400);
   const result=await db.setJSON('owner',passwordHash(password),{onlyIfNew:true});if(!result.modified)return json({error:'Owner already configured'},409);
   await db.delete('setup');return issue(db);
  }
  if(action==='login'&&request.method==='POST'){
   const ip=request.headers.get('x-nf-client-connection-ip')||'unknown';const bucket='attempts/'+digest(ip+'-'+Math.floor(Date.now()/600000));
   const prior=await db.getWithMetadata(bucket,{type:'json'});const count=prior?.data?.count??0;
   if(count>=10)return json({error:'Too many attempts. Try again in 10 minutes.'},429);
   const lock=await db.setJSON(bucket,{count:count+1},prior?{onlyIfMatch:prior.etag}:{onlyIfNew:true});if(!lock.modified)return json({error:'Please try again.'},429);
   const {password}=await body(request),owner=await db.get('owner',{type:'json'});
   if(!owner||typeof password!=='string'||password.length>256||!checkPassword(password,owner))return json({error:'Incorrect password'},401);
   return issue(db);
  }
  if(!await authenticated(request,db))return json({error:'Sign in to Iron Tusk One'},401);
  if(['contract-upload','contract-files','contract-download'].includes(action))return contractFiles(request,db);
  if(action==='logout'&&request.method==='POST'){
   const token=request.headers.get('cookie')?.match(/(?:^|;\s*)itr_one=([^;]+)/)?.[1];if(token)await db.delete('sessions/'+digest(token));return json({ok:true},200,{'set-cookie':cookie('',0)});
  }
  if(action==='records'&&request.method==='GET'){
   const entries=await Promise.all(allowedKeys.map(async key=>{const record=await db.getWithMetadata('records/'+key,{type:'json'});return [key,{data:record?.data??(key==='displayName'?'Eddie':key==='companyName'?'Iron Tusk Records':[]),etag:record?.etag??null}];}));return json(Object.fromEntries(entries));
  }
  if(action==='records'&&request.method==='POST'){
   const {key,data,etag}=await body(request);try{validateCollection(key,data);}catch{return json({error:"Invalid records. Check unique IDs and collection format."},400);}
   if(etag!==null&&typeof etag!=='string')return json({error:'Missing version'},400);
   const saved=await db.setJSON('records/'+key,data,etag?{onlyIfMatch:etag}:{onlyIfNew:true});
   if(!saved.modified)return json({error:'Records changed in another window. Reload before saving.'},409);
   const current=await db.getWithMetadata('records/'+key,{type:'json'});return json({etag:current.etag,data:current.data});
  }
  if(action==='product-sync'&&request.method==='GET')return json(await db.get('product-sync/status',{type:'json'})||{review:[],lastRun:null,intervalMinutes:15});
  if((action==='product-sync'||action==='product-review')&&request.method==='POST'){
   try{
    if(action==='product-review')await saveChoice(db,await body(request));
    const result=await syncProducts({db,catalog,kunaki:true,stripe:new Payments(process.env.STRIPE_SECRET_KEY,{timeout:5000,maxNetworkRetries:0})});return json(result);
   }catch(error){return json({error:error.message==='Product sync is already running.'?error.message:'Unable to finish product sync. Refresh the review list and try again.'},409);}
  }
  if(action==='connections'&&request.method==='GET')return json({website:ORIGIN,stripeConfigured:Boolean(process.env.STRIPE_SECRET_KEY),kunakiConfigured:Boolean(process.env.KUNAKI_USER_ID&&process.env.KUNAKI_PASSWORD),catalog});
  if(action==='orders'&&request.method==='GET'){
   const stripe=new Payments(process.env.STRIPE_SECRET_KEY),cursor=url.searchParams.get('cursor');if(cursor&&!/^cs_[A-Za-z0-9_]+$/.test(cursor))return json({error:'Invalid cursor'},400);
   const page=await stripe.checkout.sessions.list({limit:20,...(cursor?{starting_after:cursor}:{})});
   const result=[];
   for(const session of page.data){
    if(!session.livemode||session.metadata?.store_version!=='itr-stripe-v2')continue;
    let order=null,charge=null;
    if(/^[a-f0-9]{64}$/.test(session.metadata.order_key||''))order=await orders().get(session.metadata.order_key,{type:'json'});
    if(order?.sessionId!==session.id)order=null;
    if(session.payment_status==='paid'&&typeof session.payment_intent==='string'){
     try{const pi=await stripe.paymentIntents.retrieve(session.payment_intent,{expand:['latest_charge.balance_transaction']});charge=typeof pi.latest_charge==='object'?pi.latest_charge:null;}catch{}
    }
    result.push(publicOrder(session,order,charge));
   }
   return json({orders:result,nextCursor:page.has_more?page.data.at(-1)?.id:null});
  }
  if(action==='fulfillment'&&request.method==='GET'){
   const id=url.searchParams.get('session');if(!/^cs_[A-Za-z0-9_]+$/.test(id||''))return json({error:'Invalid session'},400);
   const session=await new Payments(process.env.STRIPE_SECRET_KEY).checkout.sessions.retrieve(id);
   if(!session.livemode||session.metadata?.store_version!=='itr-stripe-v2'||!/^[a-f0-9]{64}$/.test(session.metadata.order_key||''))return json({error:'Not a website order'},400);
   const order=await orders().get(session.metadata.order_key,{type:'json'});
   if(order?.sessionId!==id||!/^\d+$/.test(order.kunakiOrderId||''))return json({error:'No Kunaki order linked yet'},400);
   const xml=new XMLBuilder().build({OrderStatus:{UserId:process.env.KUNAKI_USER_ID,Password:process.env.KUNAKI_PASSWORD,OrderId:order.kunakiOrderId}});
   const response=await transport('https://kunaki.com/XMLService.ASP',{method:'POST',headers:{'Content-Type':'text/xml'},body:xml,signal:AbortSignal.timeout(15000)});
   const raw=await response.text(),match=raw.match(/<Response\b[^>]*>[\s\S]*?<\/Response>/i);if(!response.ok||!match)return json({error:'Kunaki status unavailable'},502);
   const result=new XMLParser({parseTagValue:false}).parse(match[0]).Response;if(String(result.ErrorCode)!=='0')return json({error:'Kunaki could not return this order'},502);
   return json({orderId:order.kunakiOrderId,status:result.OrderStatus,trackingType:result.TrackingType||null,trackingId:result.TrackingId||null});
  }
  return json({error:'Not found'},404);
 }catch{return json({error:'Unable to complete request. No credentials were exposed. Try again or review the connection.'},500);}
};

}
export default createHandler();
