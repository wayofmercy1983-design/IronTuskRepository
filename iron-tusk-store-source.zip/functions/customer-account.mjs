import {stripe,orders,products,verifyPaid} from './lib/store.mjs';
import {ORIGIN,customerStore,accountKey,verifiedVisitor,ensureCustomer,portalConfiguration,checkOrigin,problem} from './lib/customers.mjs';
const json=(data,status=200)=>Response.json(data,{status,headers:{'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
export function createHandler({authenticate=verifiedVisitor,accounts=customerStore,payments=stripe,orderStore=orders}={}){return async request=>{
 try{
  if(!['GET','POST'].includes(request.method))throw problem('Method not allowed',405);
  if(request.method==='POST')checkOrigin(request);
  const url=new URL(request.url),action=url.searchParams.get('action')||'me';
  if(!['me','orders','portal'].includes(action))throw problem('Unknown request',404);
  if((action==='portal')!==(request.method==='POST'))throw problem('Method not allowed',405);
  const user=await authenticate(request),db=accounts();
  if(action==='me')return json({user:{name:user.name,email:user.email}});
  const client=payments();
  if(action==='portal'){
   const account=await ensureCustomer(user,db,client),configuration=await portalConfiguration(db,client);
   const session=await client.billingPortal.sessions.create({customer:account.customerId,configuration,return_url:ORIGIN+'/account/'});
   return json({url:session.url});
  }
  const account=await db.get(accountKey(user.id),{type:'json'});if(!account?.customerId)return json({orders:[],nextCursor:null});
  const cursor=url.searchParams.get('after');if(cursor&&!/^cs_[a-zA-Z0-9_]{5,250}$/.test(cursor))throw problem('Invalid page');
  if(cursor){const previous=await client.checkout.sessions.retrieve(cursor);if(previous.customer!==account.customerId)throw problem('Invalid page',403);}
  const page=await client.checkout.sessions.list({customer:account.customerId,limit:20,...(cursor?{starting_after:cursor}:{})});
  const result=[];
  for(const session of page.data){
   if(session.customer!==account.customerId||session.payment_status!=='paid'||session.status!=='complete'||!session.livemode)continue;
   const key=session.metadata?.order_key;if(!/^[a-f0-9]{64}$/.test(key||''))continue;
   const order=await orderStore().get(key,{type:'json'});
   if(!order||order.customerAccountId!==user.id||!verifyPaid(session,order))continue;
   result.push({reference:order.reference,createdAt:order.createdAt,totalCents:session.amount_total,currency:session.currency,fulfillment:order.state==='fulfilled'?'Sent to manufacturing':order.state==='manual_review'?'We’re reviewing your order':'Payment received — preparing your order',items:order.cart.map(item=>({name:products.get(item.id)?`${products.get(item.id).artist} — ${products.get(item.id).title} (${products.get(item.id).format})`:'Music release',quantity:item.quantity}))});
  }
  return json({orders:result,nextCursor:page.has_more?page.data.at(-1)?.id:null});
 }catch(error){const status=error.status||503;return json({error:error.status?error.message:'Your account service is temporarily unavailable. Please try again.'},status);}
};}
export default createHandler();
