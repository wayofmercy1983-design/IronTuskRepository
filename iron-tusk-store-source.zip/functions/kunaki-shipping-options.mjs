import {input,normalizeCart,normalizeAddress,shipping,json,fail} from './lib/store.mjs';
export default async request=>{try{const b=await input(request);return json({options:await shipping(normalizeCart(b.cart),normalizeAddress(b.address))});}catch(e){return fail(e);}};
