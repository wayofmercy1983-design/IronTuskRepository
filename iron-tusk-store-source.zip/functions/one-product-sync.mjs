import {getStore} from '@netlify/blobs';
import Stripe from 'stripe';
import catalog from '../source/catalog.json' with {type:'json'};
import {syncProducts} from './lib/one/product-sync.mjs';
export default async () => {
 const db=getStore({name:'iron-tusk-one-private-v1',consistency:'strong'});
 if(!await db.get('owner',{type:'json'}))return;
 try{const result=await syncProducts({db,catalog,kunaki:true,stripe:new Stripe(process.env.STRIPE_SECRET_KEY,{timeout:5000,maxNetworkRetries:0})});console.log(JSON.stringify({created:result.created,review:result.review.length,warning:result.warning}));}catch{console.error('Product sync did not finish; retrying on next scheduled run.');}
};
export const config={schedule:'*/15 * * * *'};
