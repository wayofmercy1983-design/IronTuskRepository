import {VERSION,OLD,stripe,orders,verifyPaid,json,fail} from './lib/store.mjs';
export default async request=>{
 try{
  if(request.method!=='GET')return json({error:'Method not allowed'},405);
  const id=new URL(request.url).searchParams.get('session_id');if(!/^cs_(live|test)_[a-zA-Z0-9]+$/.test(id||''))throw new Error('Invalid session');
  const session=await stripe().checkout.sessions.retrieve(id);
  if(session.metadata?.store_version!==VERSION){const r=await fetch(`${OLD}/stripe-session-status?session_id=${encodeURIComponent(id)}`,{signal:AbortSignal.timeout(25000)});return new Response(await r.text(),{status:r.status,headers:{'Content-Type':'application/json','Cache-Control':'no-store'}});}
  const key=session.metadata.order_key;if(!/^[a-f0-9]{64}$/.test(key||''))throw new Error('Invalid order');
  const order=await orders().get(key,{type:'json'});if(!order)throw new Error('Order missing');
  return json({paid:verifyPaid(session,order),reference:order.reference});
 }catch(e){return fail(e);}
};
