import {VERSION,input,normalizeCart,normalizeAddress,shipping,totals,hash,orders,stripe,sessionParams,checkoutOrigin,configured,json,fail} from './lib/store.mjs';
export default async request=>{
 try{
  const b=await input(request),cart=normalizeCart(b.cart),address=normalizeAddress(b.address);configured();
  if(!/^[a-zA-Z0-9-]{20,80}$/.test(b.requestId||''))throw new Error('Invalid request ID');
  const origin=checkoutOrigin(),key=hash([VERSION,b.requestId,cart,address,b.shippingDescription,origin]),store=orders();
  let order=await store.get(key,{type:'json'});
  if(order?.sessionId){const session=await stripe().checkout.sessions.retrieve(order.sessionId);if(session.status==='open'&&session.url)return json({url:session.url});throw new Error('Checkout completed or expired; refresh cart');}
  if(!order){
   const option=(await shipping(cart,address)).find(o=>o.description===b.shippingDescription);if(!option)throw new Error('Select a current shipping option');
   order={key,reference:`ITR-${key.slice(0,12).toUpperCase()}`,cart,address,shipping:option,amounts:totals(cart,option),state:'awaiting_payment',createdAt:new Date().toISOString(),expiresAt:Math.floor(Date.now()/1000)+3600};
   const inserted=await store.setJSON(key,order,{onlyIfNew:true});if(!inserted.modified)order=await store.get(key,{type:'json'});
  }
  const session=await stripe().checkout.sessions.create(sessionParams(order,origin),{idempotencyKey:`${VERSION}-${key}`});
  const saved=await store.getWithMetadata(key,{type:'json'});
  if(!saved.data.sessionId){const written=await store.setJSON(key,{...saved.data,sessionId:session.id},{onlyIfMatch:saved.etag});if(!written.modified)throw new Error('Checkout saving; try again');}
  return json({url:session.url});
 }catch(e){return fail(e);}
};
