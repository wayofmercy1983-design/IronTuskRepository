import {VERSION,input,normalizeCart,normalizeAddress,shipping,totals,assertExpectedTotal,hash,orders,stripe,sessionParams,checkoutOrigin,configured,json,fail} from './lib/store.mjs';
import {verifiedVisitor,ensureCustomer,customerStore,attachCustomer,checkOrigin} from './lib/customers.mjs';
export default async request=>{
 try{
  checkOrigin(request);
  const b=await input(request),cart=normalizeCart(b.cart),address=normalizeAddress(b.address);configured();
  const user=await verifiedVisitor(request,{optional:true});
  const customer=user?await ensureCustomer(user,customerStore(),stripe()):null;
  if(!/^[a-zA-Z0-9-]{20,80}$/.test(b.requestId||''))throw new Error('Invalid request ID');
  const origin=checkoutOrigin(),key=hash([VERSION,b.requestId,cart,address,b.shippingDescription,origin,...(user?[user.id]:[])]),store=orders();
  let order=await store.get(key,{type:'json'});
  if(order?.sessionId){assertExpectedTotal(b.expectedTotal,order.amounts);const session=await stripe().checkout.sessions.retrieve(order.sessionId);if(session.status==='open'&&session.url)return json({url:session.url});throw new Error('Checkout completed or expired; refresh cart');}
  if(!order){
   const option=(await shipping(cart,address)).find(o=>o.description===b.shippingDescription);if(!option)throw new Error('Select a current shipping option');
   const now=Date.now(),amounts=totals(cart,option,now);
   assertExpectedTotal(b.expectedTotal,amounts);
   order={key,reference:`ITR-${key.slice(0,12).toUpperCase()}`,cart,address,shipping:option,amounts,state:'awaiting_payment',createdAt:new Date(now).toISOString(),expiresAt:Math.floor(now/1000)+3600,...(user?{customerAccountId:user.id,stripeCustomerId:customer.customerId}:{})};
   const inserted=await store.setJSON(key,order,{onlyIfNew:true});if(!inserted.modified)order=await store.get(key,{type:'json'});
  }
  assertExpectedTotal(b.expectedTotal,order.amounts);
  const session=await stripe().checkout.sessions.create(attachCustomer(sessionParams(order,origin),customer),{idempotencyKey:`${VERSION}-${key}`});
  const saved=await store.getWithMetadata(key,{type:'json'});
  if(!saved.data.sessionId){const written=await store.setJSON(key,{...saved.data,sessionId:session.id},{onlyIfMatch:saved.etag});if(!written.modified)throw new Error('Checkout saving; try again');}
  return json({url:session.url});
 }catch(e){if(e.status===401)return json({error:'Please sign in again from My Account, or sign out to check out as a guest.'},401);if(e.status===409)return json({error:e.message,pricingTime:Date.now()},409);return fail(e);}
};
