// Forward the unmodified Stripe payload to the preserved verified fulfillment backend.
export const handler = async (event) => {
  if (event.httpMethod !== "POST") return { statusCode: 405, body: "Method not allowed" };
  const signature = event.headers["stripe-signature"];
  if (!signature) return { statusCode: 400, body: "Missing Stripe signature" };
  try {
    const response = await fetch("https://6adaa9237f3da7b6ab3976a2--iron-tusk-online.netlify.app/.netlify/functions/stripe-webhook", {
      method: "POST",
      headers: { "content-type": "application/json", "stripe-signature": signature },
      body: event.isBase64Encoded ? Buffer.from(event.body || "", "base64") : event.body || "",
      signal: AbortSignal.timeout(25000)
    });
    return { statusCode: response.status, headers: { "content-type": response.headers.get("content-type") || "application/json" }, body: await response.text() };
  } catch {
    return { statusCode: 502, body: "Webhook backend unavailable; retry required" };
  }
};
