import {VERSION,OLD,stripe,fulfill,json} from './lib/store.mjs';
export default async request=>{
 if(request.method!=='POST')return json({error:'Method not allowed'},405);
 const raw=await request.text(),signature=request.headers.get('stripe-signature');if(!signature)return json({error:'Missing Stripe signature'},400);
 let event;try{event=stripe().webhooks.constructEvent(raw,signature,process.env.STRIPE_WEBHOOK_SECRET);}catch{return json({error:'Invalid signature'},400);}
 if(event.data.object.metadata?.store_version!==VERSION){try{const r=await fetch(`${OLD}/stripe-webhook`,{method:'POST',headers:{'content-type':'application/json','stripe-signature':signature},body:raw,signal:AbortSignal.timeout(25000)});return new Response(await r.text(),{status:r.status});}catch{return json({error:'Legacy handler unavailable'},502);}}
 if(!['checkout.session.completed','checkout.session.async_payment_succeeded'].includes(event.type))return json({received:true});
 try{const session=await stripe().checkout.sessions.retrieve(event.data.object.id);await fulfill(session,undefined,undefined,request.url);return json({received:true});}catch{console.error('Stripe fulfillment retry/review required',event.id);return json({error:'Fulfillment pending'},500);}
};
