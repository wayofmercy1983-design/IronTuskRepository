import {getUser,logout} from '@netlify/identity';
getUser().catch(()=>{});
export async function signOutTeam(){try{await logout();}catch{}}
