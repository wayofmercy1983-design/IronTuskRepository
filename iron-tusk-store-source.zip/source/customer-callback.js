import {getUser} from '@netlify/identity';
// Confirmation and password-reset emails may return to the store homepage.
const tokens=new URLSearchParams(location.hash.slice(1));
if(['confirmation_token','recovery_token','invite_token','email_change_token','access_token'].some(key=>tokens.has(key))){location.replace('/account/'+location.hash);}
else {getUser().catch(()=>{});}
