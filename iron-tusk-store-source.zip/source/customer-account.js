import {signup,login,logout,getUser,getSettings,handleAuthCallback,requestPasswordRecovery,updateUser,refreshSession} from '@netlify/identity';
const $=id=>document.getElementById(id),status=$('status');
const el=(tag,text,className)=>{const n=document.createElement(tag);n.textContent=text;if(className)n.className=className;return n;};
let mode='login',nextCursor=null,busy=false;
function message(text){status.textContent=text;}
function showMode(next){
 mode=next;$('auth').hidden=false;$('dashboard').hidden=true;
 $('auth-title').textContent=next==='signup'?'Create your account':next==='recover'?'Reset your password':next==='reset'?'Choose a new password':'Sign in';
 $('submit').textContent=next==='signup'?'Create account':next==='recover'?'Send reset email':next==='reset'?'Save new password':'Sign in';
 $('name-label').hidden=next!=='signup';$('name').required=next==='signup';
 $('email-label').hidden=next==='reset';$('email').required=next!=='reset';
 $('password-label').hidden=next==='recover';$('password').required=next!=='recover';$('password').minLength=next==='signup'||next==='reset'?12:1;
 $('password').autocomplete=next==='signup'||next==='reset'?'new-password':'current-password';$('password').value='';
 $('password-help').hidden=next!=='signup';$('forgot').hidden=next==='recover'||next==='reset';
 for(const type of ['login','signup'])$('show-'+type).setAttribute('aria-pressed',String(type===next));
}
async function api(action,method='GET'){
 await refreshSession();
 const r=await fetch('/.netlify/functions/customer-account?action='+action,{method,credentials:'same-origin',cache:'no-store'}),data=await r.json();
 if(!r.ok)throw Error(data.error||'Unable to load your account.');return data;
}
async function loadOrders(append=false){
 const host=$('orders');if(!append)host.replaceChildren(el('p','Loading your orders…'));
 $('more').disabled=true;
 try{
  const data=await api('orders'+(append&&nextCursor?'&after='+encodeURIComponent(nextCursor):''));
  if(!append)host.replaceChildren();else host.querySelector('.empty-orders')?.remove();
  for(const order of data.orders){
   const card=el('article','', 'order');card.append(el('h3',order.reference),el('p',new Date(order.createdAt).toLocaleDateString()+' · '+new Intl.NumberFormat('en-US',{style:'currency',currency:order.currency.toUpperCase()}).format(order.totalCents/100)),el('p',order.fulfillment));
   const list=el('ul','');for(const item of order.items)list.append(el('li',`${item.quantity} × ${item.name}`));card.append(list);host.append(card);
  }
  nextCursor=data.nextCursor;$('more').hidden=!nextCursor;
  if(!host.childNodes.length)host.append(el('p',nextCursor?'No paid orders on this page. Load more to continue.':'No orders yet. Your next purchase while signed in will appear here.','empty-orders'));
 }catch(error){if(!append)host.replaceChildren(el('p',error.message));else message(error.message);}
 finally{$('more').disabled=false;}
}
async function dashboard(){
 const {user}=await api('me');$('auth').hidden=true;$('dashboard').hidden=false;$('greeting').textContent=user.name?`Hi, ${user.name}.`:'Your account';$('account-email').textContent=user.email;message('');await loadOrders();
}
$('show-login').onclick=()=>{message('');showMode('login');};$('show-signup').onclick=()=>{message('');showMode('signup');};$('forgot').onclick=()=>{message('');showMode('recover');};
$('auth-form').onsubmit=async event=>{
 event.preventDefault();if(busy)return;busy=true;$('submit').disabled=true;message('Please wait…');
 const email=$('email').value.trim(),password=$('password').value;
 try{
  if(mode==='signup'){await signup(email,password,{full_name:$('name').value.trim()});$('password').value='';showMode('login');message('Check your inbox for a confirmation email. Follow its link to finish creating your account.');}
  else if(mode==='recover'){try{await requestPasswordRecovery(email);}catch{}message('If an account uses that email address, a password reset link will arrive shortly.');}
  else if(mode==='reset'){await updateUser({password});$('password').value='';await dashboard();message('Your password has been updated.');}
  else{await login(email,password);$('password').value='';await dashboard();}
 }catch(error){message(error.message||'Unable to continue. Please try again.');}
 finally{busy=false;$('submit').disabled=false;}
};
$('logout').onclick=async()=>{try{await logout();}finally{$('orders').replaceChildren();showMode('login');message('You’re signed out.');}};
$('portal').onclick=async()=>{$('portal').disabled=true;message('Opening Stripe’s secure payment settings…');try{const data=await api('portal','POST');const url=new URL(data.url);if(url.protocol!=='https:'||url.hostname!=='billing.stripe.com')throw Error('Unable to open secure payment settings.');location.assign(url.href);}catch(error){message(error.message);$('portal').disabled=false;}};
$('more').onclick=()=>loadOrders(true);
async function start(){try{
 const settings=await getSettings();if(settings.disableSignup)$('show-signup').hidden=true;
 const callback=await handleAuthCallback();
 if(callback?.type==='recovery'){showMode('reset');message('Choose a new password to finish your reset.');return;}
 if(await getUser()){await dashboard();return;}
 showMode('login');message(callback?.type==='confirmation'?'Email confirmed. Sign in to continue.':'');
 }catch(error){showMode('login');message(error.message||'Sign-in is temporarily unavailable.');}}
start();
