export function grossFor(report, artistId, releaseId, period) {
 const match=/^Q([1-4])\s+(\d{4})$/i.exec(period.trim());
 if(!match)throw Error('Use a quarter such as Q4 2026 for automatic Stripe revenue.');
 if(!report.complete)throw Error('Stripe history is incomplete. Gross revenue cannot be filled yet.');
 const quarter=Number(match[1]),year=Number(match[2]);
 const rows=report.rows.filter(r=>{const [y,m]=r.soldOn.split('-').map(Number);return y===year&&Math.ceil(m/3)===quarter;});
 if(rows.some(r=>r.releaseId==null))throw Error('Some sales in this quarter need a release match. Review Automatic Stripe royalties first.');
 const selected=rows.filter(r=>String(r.artistId)===String(artistId)&&String(r.releaseId)===String(releaseId));
 const seen=new Set();let total=0;
 for(const row of selected){
  if(seen.has(row.id))throw Error('A duplicate Stripe sale needs review.');seen.add(row.id);
  if(!Array.isArray(row.grossIssues)||row.grossIssues.length||!Number.isSafeInteger(row.salesCents)||row.salesCents<0)throw Error('A selected sale has a refund, dispute, or unverified amount. Review it before calculating revenue.');
  total+=row.salesCents;
 }
 if(!Number.isSafeInteger(total))throw Error('Revenue amount is too large.');
 return {cents:total,count:selected.length,checkedAt:report.checkedAt};
}

// Keep form values in React state so previews and saved records use the same amount.
export function useStripeGross(React, form, setForm, editing) {
 const recordId=editing?.id||'';
 const [choice,setChoice]=React.useState({id:recordId,mode:editing?'manual':'stripe'});
 const mode=choice.id===recordId?choice.mode:editing?'manual':'stripe';
 const setMode=value=>setChoice({id:recordId,mode:value});
 const [result,setResult]=React.useState({scope:'',ok:false,message:''});
 const [retry,setRetry]=React.useState(0);
 const scope=JSON.stringify([mode,form.artistId,form.releaseId,form.period,editing?.id||'']);
 React.useEffect(()=>{
  if(mode!=='stripe')return;
  let active=true,timer;
  const selected=Boolean(form.artistId&&form.releaseId);
  setResult({scope,ok:false,message:selected?'Checking paid Stripe sales…':'Select an artist and release to load Stripe revenue.'});
  setForm(previous=>({...previous,grossRevenue:'',distributor:'Stripe'}));
  if(!selected)return;
  async function load(){
   try{
    const response=await fetch('/.netlify/functions/one-api?action=stripe-royalties',{credentials:'same-origin',cache:'no-store'});
    const report=await response.json();if(!response.ok)throw Error(report.error||'Unable to check Stripe.');
    const value=grossFor(report,form.artistId,form.releaseId,form.period);
    if(!active)return;
    setForm(previous=>({...previous,grossRevenue:(value.cents/100).toFixed(2),distributor:'Stripe'}));
    setResult({scope,ok:true,message:`${value.count} paid sale item(s) in ${form.period}. Checked ${new Date(value.checkedAt).toLocaleString()}.`});
   }catch(error){if(active){setForm(previous=>({...previous,grossRevenue:''}));setResult({scope,ok:false,message:error.message});}}
   finally{if(active)timer=setTimeout(load,60000);}
  }
  load();return()=>{active=false;clearTimeout(timer);};
 },[scope,retry]);
 const blocked=mode==='stripe'&&(result.scope!==scope||!result.ok);
 const h=React.createElement;
 return {mode,blocked,controls:h('div',{className:'stripe-gross-controls'},
  h('label',{htmlFor:'royalty-revenue-source'},'Gross revenue source'),
  h('select',{id:'royalty-revenue-source',value:mode,onChange:e=>{setMode(e.target.value);setForm(previous=>({...previous,grossRevenue:'',distributor:e.target.value==='stripe'?'Stripe':''}));}},h('option',{value:'stripe'},'Automatic — Stripe sales'),h('option',{value:'manual'},'Manual — other revenue')),
  mode==='stripe'&&h(React.Fragment,null,h('p',null,'Paid merchandise sales after discounts, before Stripe fees and manufacturing costs. Shipping and tax excluded. Refreshes every minute.'),h('p',{role:'status','aria-live':'polite'},result.scope===scope?result.message:'Checking selection…'),h('button',{type:'button',onClick:()=>setRetry(n=>n+1)},'Refresh gross revenue'))
 )};
}
