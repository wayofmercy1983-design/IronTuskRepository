const API='/.netlify/functions/one-api';
const el=(tag,text,attrs={})=>{const n=document.createElement(tag);if(text!=null)n.textContent=text;Object.assign(n,attrs);return n;};
const money=c=>c==null?'Needs information':new Intl.NumberFormat('en-US',{style:'currency',currency:'USD'}).format(c/100);
let mounted;
async function request(action,options={}){const r=await fetch(`${API}?action=${action}`,{credentials:'same-origin',...options});const data=await r.json();if(!r.ok)throw Error(data.error||'Unable to check Stripe.');return data;}
function mount(host){
 const panel=el('section',null,{className:'stripe-royalties'});panel.setAttribute('aria-label','Automatic Stripe royalties');
 const heading=el('h2','Automatic Stripe royalties'),intro=el('p','Paid Stripe Checkout sales, matched to the contract covering each sale date. Shipping and tax are excluded. Stripe fees and confirmed manufacturing costs are deducted before the split.');
 const artistLabel=el('label','Artist',{htmlFor:'stripe-royalty-artist'}),select=el('select',null,{id:'stripe-royalty-artist'}),refresh=el('button','Check Stripe now',{type:'button'}),status=el('p'),summary=el('div',null,{className:'stripe-royalty-summary'}),list=el('div');
 status.setAttribute('role','status');status.setAttribute('aria-live','polite');
 panel.append(heading,intro,artistLabel,select,refresh,status,summary,list);
 const header=host.querySelector('.royalties-header');if(header)header.after(panel);else host.prepend(panel);
 let report,busy=false,loaded=false;
 function render(){
  if(!report)return;const rows=report.rows.filter(r=>!select.value||String(r.artistId)===select.value),ready=rows.filter(r=>!r.issues.length),pending=rows.filter(r=>r.issues.length);
  summary.replaceChildren(el('h3',report.complete?'Calculated artist royalties':'Partial calculation — scan incomplete'),el('p',pending.length&&!ready.length?'Awaiting information':money(ready.reduce((s,r)=>s+r.artistCents,0)),{className:'stripe-royalty-total'}));
  summary.append(el('p',`${rows.length} paid sale item(s) · ${pending.length} need information. ${pending.length?'The amount above excludes those items.':''}`));
  const unmatched=report.rows.filter(r=>r.artistId==null).length;if(unmatched)summary.append(el('p',`${unmatched} paid item(s) have no matched artist and are excluded. Choose All artists to review them before relying on this total.`));
  list.replaceChildren();
  if(!rows.length)list.append(el('p',report.complete?'No paid Stripe Checkout sales found for this artist.':'No matching paid sales found in the portion checked. This is not a complete result.'));
  for(const row of rows){
   const card=el('article',null,{className:'stripe-sale'});card.append(el('h3',`${row.artist} — ${row.release}${row.format?' ('+row.format+')':''}`),el('p',`${row.soldOn} · ${row.quantity} unit(s) · ${row.reference}`));
   const dl=el('dl');for(const [name,value] of [['Item revenue',money(row.salesCents)],['Stripe fee',money(row.feeCents)],['Manufacturing',money(row.manufacturingCents)],['Net revenue to split',money(row.netCents)],['Artist share',row.artistShare==null?'Needs contract':row.artistShare+'%'],['Artist royalty',money(row.artistCents)],['Iron Tusk share',money(row.labelCents)]])dl.append(el('dt',name),el('dd',value));card.append(dl);
   if(row.issues.length){const ul=el('ul');row.issues.forEach(x=>ul.append(el('li',x)));card.append(ul);}
   list.append(card);
  }
  const details=el('details'),title=el('summary','Manufacturing costs');details.append(title,el('p','Enter the actual per-unit manufacturing charge, excluding shipping. Use the date that cost took effect. This rate applies to matching sales on or after that date until a newer rate begins.'));
  const products=new Map();rows.forEach(r=>{if(r.productKey)products.set(r.productKey,r);});
  for(const [key,row] of products){
   const form=el('form'),product=el('p',`${row.release} · ${row.format} · ${key}`),costLabel=el('label','Cost per unit ($)'),cost=el('input',null,{type:'number',min:'0',step:'0.01',required:true}),dateLabel=el('label','Effective date'),dateInput=el('input',null,{type:'date',required:true}),save=el('button','Save manufacturing cost',{type:'submit'}),feedback=el('p');
   feedback.setAttribute('role','status');costLabel.append(cost);dateLabel.append(dateInput);form.append(product,costLabel,dateLabel,save,feedback);
   const existing=report.costs.filter(c=>c.productKey===key).sort((a,b)=>b.effectiveDate.localeCompare(a.effectiveDate));for(const c of existing)form.append(el('p',`${money(c.unitCents)} per unit from ${c.effectiveDate}`));
   form.addEventListener('submit',async e=>{e.preventDefault();save.disabled=true;try{await request('royalty-cost',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({productKey:key,effectiveDate:dateInput.value,unitCents:Math.round(Number(cost.value)*100)})});feedback.textContent='Saved. Rechecking royalties…';await load();}catch(e){feedback.textContent=e.message;}finally{save.disabled=false;}});details.append(form);
  }
  if(!products.size)details.append(el('p','Cost fields appear here when a matching paid sale is found.'));
  list.append(details,el('p',report.basis),el('p','These are calculated sales royalties, not a payment balance. Existing manual records, statements and payments remain separate; this view does not issue payments or create duplicate manual records.'));
 }
 async function load(){if(busy||!panel.isConnected)return;busy=true;refresh.disabled=true;status.textContent='Checking paid sales in Stripe…';try{
   report=await request('stripe-royalties');const previous=select.value;select.replaceChildren(el('option','All artists',{value:''}));for(const a of report.artists)select.append(el('option',a.name,{value:String(a.id)}));
   select.value=loaded?previous:String(report.artists.find(a=>a.name.toLowerCase()==='bone and the strangels')?.id||'');loaded=true;render();status.textContent=`Checked ${new Date(report.checkedAt).toLocaleString()}. ${report.complete?'Checkout history scan complete.':'History is incomplete; do not treat this as the full amount.'}`;
  }catch(e){status.textContent=e.message+' Displayed results, if any, are from the earlier check.';}finally{busy=false;refresh.disabled=false;}}
 select.addEventListener('change',render);refresh.addEventListener('click',load);load();
 const timer=setInterval(()=>{if(!panel.isConnected){clearInterval(timer);return;}if(!document.hidden)load();},60000);
 return panel;
}
function route(){if(!/^\/one\/royalties\/?$/.test(location.pathname)){mounted=null;return;}const host=document.querySelector('.royalties-page');if(host&&!mounted?.isConnected)mounted=mount(host);}
new MutationObserver(route).observe(document.getElementById('root'),{childList:true,subtree:true});route();
