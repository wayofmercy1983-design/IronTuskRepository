// Calendar quarters use the owner's local calendar, just like the dashboard.
export function currentQuarter(now=new Date()){
 return `Q${Math.floor(now.getMonth()/3)+1} ${now.getFullYear()}`;
}

// Historical entries retain their own accounting period, including an empty one.
export function statementPeriod(editing,now=new Date()){
 return editing ? (editing.period??'') : currentQuarter(now);
}
