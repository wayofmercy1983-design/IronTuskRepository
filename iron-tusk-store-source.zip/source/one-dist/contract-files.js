const API='/.netlify/functions/one-api';
let mounted=null;
const element=(tag,text,attrs={})=>{const node=document.createElement(tag);if(text)node.textContent=text;Object.assign(node,attrs);return node;};
async function call(action,options={}){
 const response=await fetch(`${API}?action=${action}`,{credentials:'same-origin',...options});
 const data=await response.json();if(!response.ok)throw Error(data.error||'Unable to load contract files.');return data;
}
function mount(host){
 const panel=element('section',null,{className:'contract-upload-panel'});panel.setAttribute('aria-label','Contract documents');
 const title=element('h2','Contract documents');
 const note=element('p','Choose a saved contract, then upload its signed agreement or supporting pages. Files stay private in Iron Tusk One. PDF, JPG or PNG · up to 3 MB each.');
 const label=element('label','Saved contract');const select=element('select',null,{id:'contract-file-contract'});label.htmlFor=select.id;
 const pickerLabel=element('label','Choose document');const picker=element('input',null,{type:'file',accept:'.pdf,.jpg,.jpeg,.png',id:'contract-file-picker'});pickerLabel.htmlFor=picker.id;
 const upload=element('button','Upload document',{type:'button',disabled:true});
 const refresh=element('button','Refresh contracts',{type:'button'});
 const status=element('p');status.setAttribute('role','status');status.setAttribute('aria-live','polite');
 const list=element('ul');const controls=element('div',null,{className:'contract-upload-controls'});
 controls.append(upload,refresh);panel.append(title,note,label,select,pickerLabel,picker,controls,status,list);const header=host.querySelector('.contracts-header');if(header)header.after(panel);else host.prepend(panel);
 let busy=false,version=0;
 const enabled=()=>{upload.disabled=busy||!select.value||!picker.files.length;refresh.disabled=busy;select.disabled=busy;picker.disabled=busy;};
 async function files(){
  const current=++version;list.replaceChildren();if(!select.value)return;
  try{const data=await call('contract-files&contractId='+encodeURIComponent(select.value));if(current!==version)return;
   for(const file of data.files){const li=element('li');const link=element('a',file.name,{href:`${API}?action=contract-download&id=${encodeURIComponent(file.id)}`});
    li.append(link,element('span',` · ${Math.ceil(file.size/1024)} KB · ${new Date(file.uploadedAt).toLocaleDateString()}`));list.append(li);}
   status.textContent=data.files.length?`${data.files.length} document${data.files.length===1?'':'s'} saved.`:'No documents uploaded for this contract yet.';
  }catch(e){if(current===version)status.textContent=e.message;}
 }
 async function contracts(){
  status.textContent='Loading saved contracts…';busy=true;enabled();
  try{const records=await call('records');const prior=select.value;select.replaceChildren(element('option','Select a saved contract',{value:''}));
   for(const c of records.contracts.data){const artist=records.artists.data.find(a=>String(a.id)===String(c.artistId));select.append(element('option',`${artist?.name||c.artist||'Artist'} — ${c.contractName||c.contractNumber||'Untitled contract'}`,{value:String(c.id)}));}
   if([...select.options].some(o=>o.value===prior))select.value=prior;
   status.textContent=records.contracts.data.length?'Select a contract to see its documents.':'Save a contract using the form below, then choose Refresh contracts to attach its document.';
   if(select.value)await files();
  }catch(e){status.textContent=e.message;}finally{busy=false;enabled();}
 }
 select.addEventListener('change',()=>{enabled();files();});picker.addEventListener('change',enabled);refresh.addEventListener('click',contracts);
 upload.addEventListener('click',async()=>{
  if(busy)return;const file=picker.files[0];if(!select.value||!file)return;
  if(!file.size||file.size>3*1024*1024){status.textContent='Choose a nonempty file up to 3 MB.';return;}
  busy=true;enabled();status.textContent='Uploading document…';
  try{const data=await new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(String(reader.result).split(',')[1]);reader.onerror=()=>reject(Error('Unable to read this file. Choose it again.'));reader.readAsDataURL(file);});
   await call('contract-upload',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({contractId:select.value,name:file.name,type:file.type,data})});picker.value='';await files();
  }catch(e){status.textContent=e.message;}finally{busy=false;enabled();}
 });
 contracts();return panel;
}
function route(){
 if(!/^\/one\/contracts\/?$/.test(location.pathname)){mounted=null;return;}
 const host=document.querySelector('.contracts-page');if(!host||mounted?.isConnected)return;mounted=mount(host);
}
new MutationObserver(route).observe(document.getElementById('root'),{childList:true,subtree:true});route();
